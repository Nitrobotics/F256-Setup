# About the FPGA loads

Consult the [F256 Wiki](https://wiki.f256foenix.com/index.php?title=FPGA_Releases) in order
to decide which load you use to configure your F256K or F256 Jr. The page also links to a youtube
video which explains how to perform the update.
