python fnxmgr.zip --port /dev/ttyUSB0 --binary ../graphics.bin --address 010000
python fnxmgr.zip --port /dev/ttyUSB0 --binary demo2.bas --address 010a00
python fnxmgr.zip --port /dev/ttyUSB0 --binary save.bas --address 28000
