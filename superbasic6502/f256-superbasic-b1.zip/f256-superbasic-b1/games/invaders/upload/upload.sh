python fnxmgr.zip --port /dev/ttyUSB0 --binary ../graphics.bin --address 010000
python fnxmgr.zip --port /dev/ttyUSB0 --binary inv.bas --address 011600
python fnxmgr.zip --port /dev/ttyUSB0 --binary save.bas --address 28000
