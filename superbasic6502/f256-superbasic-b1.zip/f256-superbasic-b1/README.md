# superbasic
Improved BASIC for F256 Junior

To build everything you need the following 4 repositories.

The emulator
https://github.com/paulscottrobson/junior-emulator

Basic Repository
https://github.com/paulscottrobson/superbasic

Command Line Foenix256 uploader 
https://github.com/pweingar/FoenixMgr

DOS / Kernel Interface
https://github.com/ghackwrench/F256_Jr_Kernel_DOS

BootScreens.
https://github.com/WartyMN/Foenix-F256JR-bootscreens

