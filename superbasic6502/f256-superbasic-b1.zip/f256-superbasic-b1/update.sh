#!/bin/bash
git add * && git add -u * . && git commit -m "Update" && git push