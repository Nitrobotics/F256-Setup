python utility/scanread/scanread.py
