while :
do
	make testbasic test autorun
	make testbasic astest autorun
	make testbasic sastest autorun
	make testbasic artest autorun
	make testbasic linetest
done
