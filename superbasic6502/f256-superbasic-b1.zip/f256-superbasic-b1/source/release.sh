make -B pullkernel updatekernel build release
