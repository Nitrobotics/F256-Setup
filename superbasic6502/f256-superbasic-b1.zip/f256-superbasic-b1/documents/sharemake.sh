cp common.make ../../junior-emulator/documents


